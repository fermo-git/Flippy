// Llamadas a la IA. La app NUNCA lleva claves: habla con tu proxy (carpeta /proxy).
import { analizarDemo, transcribirDemo } from './demo';
import { Analisis, normalizarAnalisis } from './tipos';

const API_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, '');
const API_TOKEN = process.env.EXPO_PUBLIC_API_TOKEN;

/** Si no configuraste EXPO_PUBLIC_API_URL, la app funciona con datos simulados. */
export const MODO_DEMO = !API_URL;

const TIMEOUT_MS = 90_000;

async function pedir(ruta: string, init: RequestInit): Promise<unknown> {
  const control = new AbortController();
  const timer = setTimeout(() => control.abort(), TIMEOUT_MS);
  try {
    const headers: Record<string, string> = { ...(init.headers as Record<string, string>) };
    if (API_TOKEN) headers['x-app-token'] = API_TOKEN;
    const res = await fetch(`${API_URL}${ruta}`, { ...init, headers, signal: control.signal });
    const cuerpo: unknown = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg =
        typeof cuerpo === 'object' && cuerpo !== null && 'error' in cuerpo
          ? String((cuerpo as { error: unknown }).error)
          : `Error ${res.status}`;
      throw new Error(msg);
    }
    return cuerpo;
  } catch (e) {
    if (e instanceof Error && e.name === 'AbortError') {
      throw new Error('El servidor tardó demasiado en responder.');
    }
    if (e instanceof TypeError) {
      throw new Error('No se pudo conectar. Revisa tu internet y la URL del proxy.');
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

export async function transcribir(audioUri: string): Promise<string> {
  if (MODO_DEMO) return transcribirDemo();

  const form = new FormData();
  // En React Native, un archivo se adjunta como { uri, name, type }.
  form.append('file', { uri: audioUri, name: 'nota.m4a', type: 'audio/m4a' } as unknown as Blob);

  const r = await pedir('/transcribe', { method: 'POST', body: form });
  const texto = typeof r === 'object' && r !== null && 'texto' in r ? (r as { texto: unknown }).texto : '';
  return typeof texto === 'string' ? texto.trim() : '';
}

export async function analizar(texto: string): Promise<Analisis> {
  if (MODO_DEMO) return analizarDemo(texto);

  const r = await pedir('/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ texto }),
  });
  return normalizarAnalisis(r);
}
