import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';

import { listarEntradas } from '@/lib/db';
import { Entrada } from '@/lib/tipos';

/** Carga las entradas y las vuelve a leer cada vez que la pantalla recupera el foco. */
export function useEntradas() {
  const [entradas, setEntradas] = useState<Entrada[]>([]);
  const [cargando, setCargando] = useState(true);

  const recargar = useCallback(async () => {
    try {
      setEntradas(await listarEntradas());
    } finally {
      setCargando(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      recargar();
    }, [recargar]),
  );

  return { entradas, cargando, recargar };
}
